public interface PrimeSieve {
    public boolean isPrime(int p);
    public void printPrimes();
}